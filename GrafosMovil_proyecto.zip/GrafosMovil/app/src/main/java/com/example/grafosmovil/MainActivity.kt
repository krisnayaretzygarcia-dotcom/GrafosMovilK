package com.example.grafosmovil

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : Activity() {
    private val vertices = mutableListOf<String>()
    private val edges = mutableListOf<Pair<Int, Int>>()
    private lateinit var graphView: GraphView
    private lateinit var status: TextView
    private var selectedForEdge: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vertices.addAll(listOf("A", "B", "C", "D"))
        edges.addAll(listOf(0 to 1, 0 to 2, 1 to 3))
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(Color.rgb(248, 246, 252))
        }
        val title = TextView(this).apply {
            text = "GRAFOS MÓVIL"
            textSize = 24f
            setTextColor(Color.rgb(55, 43, 91))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Explora vértices, aristas y recorridos"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)
        graphView = GraphView()
        root.addView(graphView, LinearLayout.LayoutParams(-1, 0, 1f))

        val row1 = LinearLayout(this)
        row1.addView(button("Agregar vértice") { addVertex() }, weight())
        row1.addView(button("Agregar arista") { addEdge() }, weight())
        root.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(button("BFS") { showTraversal(true) }, weight())
        row2.addView(button("DFS") { showTraversal(false) }, weight())
        row2.addView(button("Matriz") { showMatrix() }, weight())
        root.addView(row2)
        val row3 = LinearLayout(this)
        row3.addView(button("Reiniciar") {
            vertices.clear(); edges.clear(); selectedForEdge = null
            graphView.invalidate(); status.text = "Grafo vacío. Agrega vértices para comenzar."
        }, weight())
        root.addView(row3)
        status = TextView(this).apply {
            text = "Toca «Agregar vértice» o «Agregar arista» para editar el grafo."
            textSize = 13f
            setTextColor(Color.rgb(45, 39, 61))
            setPadding(8, 12, 8, 8)
        }
        root.addView(status)
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(3, 4, 3, 4) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setOnClickListener { action() }
    }

    private fun addVertex() {
        if (vertices.size >= 12) { status.text = "Límite de 12 vértices alcanzado."; return }
        val name = "V${vertices.size + 1}"
        vertices.add(name)
        graphView.invalidate()
        status.text = "Se agregó el vértice $name."
    }

    private fun addEdge() {
        if (vertices.size < 2) { status.text = "Agrega al menos dos vértices."; return }
        val names = vertices.toTypedArray()
        AlertDialog.Builder(this).setTitle("Selecciona el primer vértice")
            .setItems(names) { _, first ->
                AlertDialog.Builder(this).setTitle("Selecciona el segundo vértice")
                    .setItems(names) { _, second ->
                        if (first == second) status.text = "No se permiten lazos en esta versión."
                        else if (edges.any { (a,b) -> (a == first && b == second) || (a == second && b == first) })
                            status.text = "Esa arista ya existe."
                        else {
                            edges.add(first to second); graphView.invalidate()
                            status.text = "Arista agregada: ${vertices[first]} — ${vertices[second]}."
                        }
                    }.show()
            }.show()
    }

    private fun adjacency(): List<MutableList<Int>> {
        val adj = List(vertices.size) { mutableListOf<Int>() }
        edges.forEach { (a,b) -> if (a < vertices.size && b < vertices.size) { adj[a].add(b); adj[b].add(a) } }
        return adj
    }

    private fun showTraversal(bfs: Boolean) {
        if (vertices.isEmpty()) { status.text = "El grafo está vacío."; return }
        val startNames = vertices.toTypedArray()
        AlertDialog.Builder(this).setTitle("Vértice inicial")
            .setItems(startNames) { _, start ->
                val adj = adjacency()
                val visited = mutableSetOf<Int>()
                val order = mutableListOf<Int>()
                if (bfs) {
                    val q = ArrayDeque<Int>(); q.add(start); visited.add(start)
                    while (q.isNotEmpty()) {
                        val v = q.removeFirst(); order.add(v)
                        adj[v].forEach { if (visited.add(it)) q.add(it) }
                    }
                } else {
                    fun visit(v: Int) {
                        visited.add(v); order.add(v)
                        adj[v].forEach { if (it !in visited) visit(it) }
                    }
                    visit(start)
                }
                status.text = "${if (bfs) "BFS" else "DFS"} desde ${vertices[start]}: " +
                    order.joinToString(" → ") { vertices[it] } +
                    if (order.size < vertices.size) " (hay vértices desconectados)" else ""
            }.show()
    }

    private fun showMatrix() {
        val adj = adjacency()
        val header = "    " + vertices.joinToString("  ") + "\n"
        val body = vertices.indices.joinToString("\n") { i ->
            vertices[i] + "   " + vertices.indices.joinToString("  ") { j ->
                if (j in adj[i]) "1" else "0"
            }
        }
        AlertDialog.Builder(this).setTitle("Matriz de adyacencia")
            .setMessage(header + body).setPositiveButton("Cerrar", null).show()
    }

    inner class GraphView : View(this@MainActivity) {
        private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(103, 80, 164); style = Paint.Style.FILL }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(120, 112, 139); strokeWidth = 5f }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f; textAlign = Paint.Align.CENTER }
        private val positions = mutableListOf<Pair<Float,Float>>()
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(248,246,252))
            positions.clear()
            val n = vertices.size
            if (n == 0) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 34f; textAlign = Paint.Align.CENTER }
                canvas.drawText("Tu grafo aparecerá aquí", width/2f, height/2f, p); return
            }
            val cx = width / 2f; val cy = height / 2f
            val radius = (minOf(width, height) * 0.36f).coerceAtLeast(45f)
            repeat(n) { i ->
                val angle = -Math.PI / 2 + 2 * Math.PI * i / n
                positions.add(cx + radius * cos(angle).toFloat() to cy + radius * sin(angle).toFloat())
            }
            edges.forEach { (a,b) ->
                if (a < positions.size && b < positions.size) {
                    val (x1,y1) = positions[a]; val (x2,y2) = positions[b]
                    canvas.drawLine(x1,y1,x2,y2,edgePaint)
                }
            }
            positions.forEachIndexed { i, (x,y) ->
                canvas.drawCircle(x,y,31f,nodePaint)
                canvas.drawText(vertices[i],x,y+10f,textPaint)
            }
        }
    }
}
